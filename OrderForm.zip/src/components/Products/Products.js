import React from 'react';
import ProductActions from "./ProductActions/ProductActions";

import './Products.css';

class Products extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="productListWrapper">
                <div className="productList">
                    <div className="noProducts">
                        <span>You haven’t added products yet.</span>
                    </div>
                </div>
                <ProductActions/>
            </div>
        )
    }
}

export default Products;
