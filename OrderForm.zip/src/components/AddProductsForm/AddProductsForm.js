import React from 'react';
import ProductsFromSku from "./ProductsFromSku/ProductsFromSku";
import ProductsFromCsv from "./ProductsFromCsv/ProductsFromCsv";

import './AddProductsForm.css';

class AddProductsForm extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="addProductsForm">
                <ProductsFromSku />
                <ProductsFromCsv />
            </div>
        )
    }
}

export default AddProductsForm;
