import React from 'react';

import './ProductsFromSku.css';

class ProductsFromSku extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="multipleProducts">
                <h1>Add Multiple Products</h1>
                <label className="inputLabel" for="sku">Enter multiple SKU(s)</label>
                <textarea cols="30" rows="3" id="sku" class="skuTextarea"
                          placeholder="Use new line for each separate SKU. Add just SKUs or also specify qty and options."/>
                <span className="comment">Format: SKU,qty</span>
                <span className="comment">Example: WT08,5</span>
                <div className="productFormButtonWrapper">
                    <button className="addToList">Add to List</button>
                </div>
            </div>
        )
    }
}

export default ProductsFromSku;
