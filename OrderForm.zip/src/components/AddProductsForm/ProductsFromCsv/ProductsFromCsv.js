import React from 'react';

import './ProductsFromCsv.css';

class ProductsFromCsv extends React.Component {
    constructor(props) {
        super(props);
        this.defaultInputText = "Choose file +";

        this.state = {
            fileInputLabel: this.defaultInputText
        }
    }

    fileUpload = (e) => {
        let files = e.target.files;
        this.setState({fileInputLabel: files.length !== 0 ? files[0].name : this.defaultInputText});
    }

    render() {
        return (
            <div className="addFromFile">
                <span className="inputLabel">Add from File</span>
                <input type="file" id="fileUpload" accept=".xml,.csv" onChange={this.fileUpload}/>
                <label htmlFor="fileUpload" className="inputLabel">{ this.state.fileInputLabel }</label>
                <div className="comment">File must be in .csv format and include “SKU” and “QTY” columns.</div>
                <div className="productFormButtonWrapper">
                    <button className="upload">Import</button>
                </div>
            </div>
        )
    }
}

export default ProductsFromCsv;
