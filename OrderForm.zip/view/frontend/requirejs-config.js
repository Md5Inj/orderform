var config = {
    map: {
        '*': {
            'react': 'Freento_OrderForm/js/index_bundle'
        }
    },
};
